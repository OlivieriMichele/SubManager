package com.example.submanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.submanager.model.Subscription
import com.example.submanager.ui.theme.AccentColors

@Composable
fun HomeScreen(
    subscriptions: List<Subscription>,
    totalMonthly: Double,
    categoriesCount: Int,
    isDark: Boolean,
    onNavigateToCategories: () -> Unit,
    onToggleDarkMode: () -> Unit
) {
        Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        StatusBarPlaceholder(isDark)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Header Section
                HeaderSection(
                    isDark = isDark,
                    onToggleDarkMode = onToggleDarkMode
                )

                // Main Card
                MainCard(
                    totalMonthly = totalMonthly,
                    totalYearly = totalMonthly * 12,
                    isDark = isDark
                )

                // Stats Cards
                StatsCards(
                    subscriptionCount = subscriptions.size,
                    expiringCount = 2, // Valore fisso del mockup
                    categoriesCount = categoriesCount,
                    isDark = isDark
                )

                // Categories Button
                CategoriesButton(isDark, onNavigateToCategories)

                // Subscriptions List Title
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Prossimi Rinnovi",
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    TextButton(onClick = { /* TODO: Vedi tutti */ }) {
                        Text(
                            text = "Vedi tutti",
                            color = if (isDark) Color(0xFF60A5FA) else Color(0xFF3B82F6), // blue-400/500
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Subscriptions List
            items(subscriptions) { sub ->
                SubscriptionItem(subscription = sub, isDark = isDark)
                Spacer(modifier = Modifier.height(12.dp))
            }

            item {
                Spacer(modifier = Modifier.height(120.dp)) // Spazio per la Navigation Bar
            }
        }
    }

    // FAB e Bottom Navigation Bar (Da implementare come composable separati in un layer superiore,
    // ma qui li aggiungiamo per completezza del layout)

    // ... Implementazione di FAB e Bottom Nav (omessa per brevità, focalizziamoci sul contenuto della schermata)
}

// Composables estratti per pulizia
@Composable
private fun StatusBarPlaceholder(isDark: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp) // Altezza della Status Bar
            .background(MaterialTheme.colorScheme.background)
    )
}

@Composable
private fun HeaderSection(isDark: Boolean, onToggleDarkMode: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 32.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Benvenuto",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Abbonamenti",
                fontSize = 32.sp,
                color = MaterialTheme.colorScheme.onPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Dark Mode Toggle Button (come nel mockup)
            IconButton(
                onClick = onToggleDarkMode,
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.onSurface, RoundedCornerShape(20.dp))
                    .border(1.dp, MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(20.dp))
            ) {
                Icon(
                    imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = "Tema",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Notification Button
            IconButton(
                onClick = { /* ... */ },
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.onSurface, RoundedCornerShape(20.dp))
                    .border(1.dp, MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(20.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifiche",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun MainCard(totalMonthly: Double, totalYearly: Double, isDark: Boolean) {
    val brush = if (isDark) Brush.linearGradient(listOf(AccentColors.mainGradientStart, AccentColors.mainGradientEnd))
    else Brush.linearGradient(listOf(AccentColors.mainGradientLightStart, AccentColors.mainGradientLightEnd))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 24.dp)
            .background(brush, RoundedCornerShape(24.dp))
            .padding(24.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "Spesa Mensile",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "€${String.format("%.2f", totalMonthly)}",
                        color = Color.White,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = "Trend",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Divider(color = Color.White.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Annuale",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 14.sp
                )
                Text(
                    text = "€${String.format("%.2f", totalYearly)}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun StatsCards(
    subscriptionCount: Int,
    expiringCount: Int,
    categoriesCount: Int,
    isDark: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 24.dp)
            .background(MaterialTheme.colorScheme.onSurface, RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(16.dp))
            .padding(vertical = 20.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        StatItem(
            value = subscriptionCount,
            label = "Attivi",
            color = if (isDark) Color(0xFF60A5FA) else Color(0xFF3B82F6), // blue
            isDark = isDark
        )
        // Separator
        Divider(
            modifier = Modifier
                .height(40.dp)
                .width(1.dp),
            color = MaterialTheme.colorScheme.surfaceContainer
        )
        StatItem(
            value = expiringCount,
            label = "In scadenza",
            color = if (isDark) Color(0xFFC084FC) else Color(0xFF9333EA), // purple
            isDark = isDark
        )
        // Separator
        Divider(
            modifier = Modifier
                .height(40.dp)
                .width(1.dp),
            color = MaterialTheme.colorScheme.surfaceContainer
        )
        StatItem(
            value = categoriesCount,
            label = "Categorie",
            color = if (isDark) Color(0xFF818CF8) else Color(0xFF6366F1), // indigo
            isDark = isDark
        )
    }
}

@Composable
private fun StatItem(value: Int, label: String, color: Color, isDark: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value.toString(),
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSecondary
        )
    }
}

@Composable
private fun CategoriesButton(isDark: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 24.dp)
            .background(MaterialTheme.colorScheme.onSurface, RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Visualizza per Categorie",
            color = MaterialTheme.colorScheme.onPrimary,
            fontWeight = FontWeight.Medium
        )
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSecondary
        )
    }
}

@Composable
private fun SubscriptionItem(subscription: Subscription, isDark: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.onSurface, RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(subscription.color, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = subscription.name.first().toString(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = subscription.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = null,
                    modifier = Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.onSecondary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = subscription.nextBilling,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSecondary
                )
                Text(
                    text = " • ",
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    fontSize = 12.sp,
                )
                Text(
                    text = subscription.category,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSecondary
                )
            }
        }

        // Price
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "€${String.format("%.2f", subscription.price)}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onPrimary
            )
            Text(
                text = "/mese",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSecondary
            )
        }
    }
}